import webbrowser
url='http://www.pythonchallenge.com/pc/def/' + str(2**38) +'.html'
webbrowser.open(url)